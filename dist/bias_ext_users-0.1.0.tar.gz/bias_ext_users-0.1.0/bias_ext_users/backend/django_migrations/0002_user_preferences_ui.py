from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("users", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="user",
            name="preferences_ui",
            field=models.JSONField(blank=True, default=dict),
        ),
    ]

